package com.skc.UserDao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.skc.lnd.model.CreateAccount;

import com.skc.lnd.util.UserRowMapper;

import org.springframework.jdbc.core.JdbcTemplate;


public class UserDaoImpl {
	private JdbcTemplate template;

	

	public UserDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserDaoImpl(JdbcTemplate template) {
		super();
		this.template = template;
	}

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public List<CreateAccount> getAllUsers(){
		List<CreateAccount> all=null;
		String query="SELECT STUDENT_NAME,STUDENT_EMAIL,CONTACT_NUMBER,CODER_NAME,GENDER,USER_TYPE,STUDENT_ID,PASSCODE,QUESTION,ANSWER FROM STUDENT_DETAILS_XBBNHBK";
		System.out.println(query);
		all = template.query(query,new UserRowMapper());
		return all;
		
	}
	public CreateAccount getEmployeeById(String searchById)
	{
		CreateAccount foundEmployee =null;
		String querry="SELECT STUDENT_NAME,STUDENT_EMAIL,CONTACT_NUMBER,CODER_NAME,GENDER,USER_TYPE,STUDENT_ID,PASSCODE,QUESTION,ANSWER FROM STUDENT_DETAILS_XBBNHBK WHERE STUDENT_ID='"+searchById+"'";
		foundEmployee=template.queryForObject(querry,new UserRowMapper());
		return foundEmployee;
	}
}
