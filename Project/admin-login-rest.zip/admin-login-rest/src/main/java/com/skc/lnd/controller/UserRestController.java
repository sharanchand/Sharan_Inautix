package com.skc.lnd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.skc.UserDao.UserDaoImpl;
import com.skc.lnd.model.CreateAccount;

@RestController
public class UserRestController {
	@Autowired 
	private UserDaoImpl userDaoImpl;
	
	@GetMapping("/users")
	public List<CreateAccount> getAllEmployee()
	{
		System.out.println("Users");
		return userDaoImpl.getAllUsers();
	}
	
	@GetMapping("/users/{id}")
	public ResponseEntity<Object> getEmployee(@PathVariable("id") String id)
	{
		CreateAccount emp= userDaoImpl.getEmployeeById(id);
		if(emp==null)
		{
			return new ResponseEntity<Object>("Employee not found with id"+id,HttpStatus.NOT_FOUND);
		}
		else
		{
			return new ResponseEntity<Object>(emp,HttpStatus.OK);
		}
				
	}
}
