package com.skc.lnd.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.skc.lnd.model.CreateAccount;

public class UserRowMapper implements RowMapper<CreateAccount> {

	@Override
	public CreateAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		//STUDENT_NAME,STUDENT_EMAIL,CONTACT_NUMBER,CODER_NAME,GENDER,USER_TYPE,STUDENT_ID,PASSCODE,QUESTION,ANSWER
		CreateAccount userDetails =  new CreateAccount();
		/*System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4));*/
		userDetails.setName(rs.getString(1));
		userDetails.setEmail(rs.getString(2));
		userDetails.setContactNumber(rs.getString(3));
		userDetails.setCoderName(rs.getString(4));
		userDetails.setGender(rs.getString(5));
		userDetails.setUserType(rs.getString(6));
		userDetails.studentId=rs.getString(7);
		userDetails.setPassword(rs.getString(8));
		userDetails.setQuestion(rs.getString(9));
		userDetails.setAnswer(rs.getString(10));

		return userDetails;
	}

}
