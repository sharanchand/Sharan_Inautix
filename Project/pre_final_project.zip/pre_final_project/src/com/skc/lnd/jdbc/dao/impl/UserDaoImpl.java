package com.skc.lnd.jdbc.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.skc.lnd.jdbc.model.CreateAccount;
import com.skc.lnd.jdbc.model.QuestionAnswer;
import com.skc.lnd.jdbc.util.ConnectionFactory;
import com.skc.lnd.jdbc.util.DBUtil;
import com.skc.lnd.jdbc.util.QueryConstants;

public class UserDaoImpl{
	public static int studentID; 
	//private Connection connection;
	//private PreparedStatement preparedStatment;

	public UserDaoImpl() {
	}
	//FindError
	public static boolean findError(Connection conn,CreateAccount account) throws SQLException
	{
		String sql= QueryConstants.FIND_ERROR;
		PreparedStatement pstm=conn.prepareStatement(sql);
		pstm.setString(1, account.getEmail());
		pstm.setString(2, account.getContactNumber());
		ResultSet rs = pstm.executeQuery();
		if(rs.next()){
			return true;
		}
		else{
			return false;
		}
	}
	
	//CreateAccount
	public static CreateAccount findUser(Connection conn, String eMail, String password) throws SQLException {
		try{
		String sql = QueryConstants.FIND_USER;
		//System.out.println(sql);
		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setString(1, eMail);
		pstm.setString(2, password);
		ResultSet rs = pstm.executeQuery();
		//System.out.println(rs);
		if (rs.next()) {
			String studentName = rs.getString("Student_Name");
			CreateAccount user = new CreateAccount();
			user.setEmail(eMail);
			user.setPassword(password);
			user.setName(studentName);
			user.setCoderName(rs.getString("Coder_NAME"));
			user.setUserType(rs.getString("USER_TYPE"));
			user.studentId=rs.getString("STUDENT_ID");
			return user;
		}
		}
		catch(Exception e){System.out.println(e.getMessage());}
		return null;
	}
	
	//GetStudentID
	public static void getStudentID(Connection conn) throws SQLException
	{
		String searchIDSql=QueryConstants.SEARCH_ID;
		PreparedStatement pstm=conn.prepareStatement(searchIDSql);
		ResultSet rs = pstm.executeQuery();
		if (rs.next()) {
			String ssid = rs.getString("STUDENT_ID");
			int index = 3;
			while (ssid.charAt(index) == '0') {
				index++;
			}
			ssid = ssid.substring(index);
			studentID = Integer.parseInt(ssid);
			studentID++;
		}
		else {
			studentID = 1;
		}
	}
	
	//addUser
	public static boolean addUser(Connection conn,CreateAccount account) throws SQLException
	{
		try{
		String sql= QueryConstants.INSERT_USER;

		String studentIDSql="S13";

		getStudentID(conn);

		int temp=studentID;
		int count=0;
		while(temp>0)
		{
			temp/=10;
			count++;
		}

		for(int zeros=7;zeros>count;zeros--)
		{
			studentIDSql+="0";
		}

		studentIDSql+=studentID;
		//System.out.println(studentIDSql);
		PreparedStatement pstm=conn.prepareStatement(sql);
		pstm.setString(1,studentIDSql);
		pstm.setString(2,account.getName());
		pstm.setString(3, account.getEmail());
		pstm.setLong(4,Long.parseLong(account.getContactNumber()));
		pstm.setString(5,account.getPassword());
		pstm.setString(6,account.getCoderName());
		pstm.setString(7,account.getGender());
		pstm.setString(8,account.getQuestion());
		pstm.setString(9,account.getAnswer());
		pstm.setString(10,account.getUserType());

		pstm.executeUpdate();
		}
		catch(Exception e){System.out.println(e.getMessage());
		return false;
		}
		return true;
	}
	
	public static boolean addQuestion(Connection conn,QuestionAnswer questionAnswer,String studentId) throws SQLException
	{
		String sql= QueryConstants.ADD_QUESTION;
		String query=QueryConstants.SEARCH_QUESTION_ID;
		int qid=getQuestionId(conn, query);
		qid++;
		System.out.println("qid :"+qid);
		PreparedStatement pstm=conn.prepareStatement(sql);
		pstm.setString(1,studentId);
		pstm.setInt(2, qid);
		pstm.setString(3,questionAnswer.getQuestion());
		pstm.setString(4,questionAnswer.getClue());
		int i=pstm.executeUpdate();
		System.out.println("i : "+i);
		if(i==0)
			return false;
		else
			return true;
	}
	public static int getQuestionId(Connection conn,String query) throws SQLException
	{
		PreparedStatement pstm=conn.prepareStatement(query);
		ResultSet rs=pstm.executeQuery();
		System.out.println("query : "+query);
		if(rs.next())
		{
			int n=rs.getInt("QUESTION_ID");
			System.out.println("n :"+n);
			return n;
		}
		else
		{
			return 1;
		}
	}
	public static ArrayList<QuestionAnswer> getAllQuestions(Connection conn) throws SQLException
	{
		String query=QueryConstants.ALL_QUESTIONS;
		ArrayList<QuestionAnswer> al=new ArrayList<QuestionAnswer>();
		PreparedStatement pstm=conn.prepareStatement(query);
		ResultSet rs=pstm.executeQuery();
		System.out.println("query : "+query);
		QuestionAnswer questionAnswer;
		while(rs.next())
		{
			questionAnswer=new QuestionAnswer();
			questionAnswer.setQuestion(rs.getString("QUESTION"));
			questionAnswer.setClue(rs.getString("CLUE"));
			questionAnswer.setQuestionId(rs.getInt("QUESTION_ID"));
			questionAnswer.setStudentId(rs.getString("STUDENT_ID"));
			al.add(questionAnswer);
		}
		return al;
	}
	public static QuestionAnswer getQuestionById(Connection conn,int id) throws SQLException
	{
		QuestionAnswer questionAnswer;
		PreparedStatement pstm=conn.prepareStatement(QueryConstants.GET_QUESTION_BY_ID);
		pstm.setInt(1, id);
		ResultSet rs=pstm.executeQuery();
		if(rs.next())
		{
			questionAnswer=new QuestionAnswer();
			//SELECT QUESTION, CLUE FROM QUESTION_ANSWER_XBBNHBK WHERE QUESTION_ID= 
			questionAnswer.setQuestion(rs.getString("QUESTION"));
			questionAnswer.setClue(rs.getString("CLUE"));
			questionAnswer.setQuestionId(id);
			//System.out.println("n :"+n);
			return questionAnswer;
		}
		return null;
	}
}
