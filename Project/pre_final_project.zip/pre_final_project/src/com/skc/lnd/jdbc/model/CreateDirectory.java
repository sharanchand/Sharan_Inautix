package com.skc.lnd.jdbc.model;

import java.io.File;

public class CreateDirectory {

	static boolean successful = false;

	public static boolean createDir(String st) {
		/* File dir = new File("c:/TestDirectory/cdtb/bcb"); */
		System.out.println("Folder Path: "+st);
		File dir = new File(st);

		successful = dir.mkdirs();
		if (successful) {
			// creating the directory succeeded
			 System.out.println("directory was created successfully");
			return successful;
		} else {
			 System.out.println("failed trying to create the directory");
			successful = dir.delete();
			System.out.println(successful);
			File[] files = dir.listFiles();
			 System.out.println(files);
			if (files != null) { // some JVMs return null for empty dirs
				for (File f : files) {
					if (f.isDirectory()) {
						 System.out.println(f);
					} else {
						 System.out.println("else : "+f);
						f.delete();
					}
				}
			}
			dir.delete();
			createDir(st);
			return successful;
		}
	}

}