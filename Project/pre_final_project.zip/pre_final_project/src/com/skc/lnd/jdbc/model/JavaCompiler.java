package com.skc.lnd.jdbc.model;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.*;

import com.skc.lnd.jdbc.servlet.GetCodeOutput;
import com.skc.lnd.jdbc.servlet.GetOutput;

public class JavaCompiler {
	static String s="";
	static int k=0;
  private static void printLines(String name, InputStream ins) throws Exception {
    String line = null;
    /*s=new String();*/
    BufferedReader in = new BufferedReader(new InputStreamReader(ins));
    while ((line = in.readLine()) != null) {
        //System.out.println(name + "  " + line);
    	s+=line+"\n";
    }
    System.out.println("s: "+s);
    
  }

  private static int runProcess(String command) throws Exception {
    Process pro = Runtime.getRuntime().exec(command);
    s=new String();
    printLines(command + " stderr:", pro.getErrorStream());

    printLines(command + " stdout:", pro.getInputStream());
    pro.waitFor();
    return pro.exitValue();
  }

  public static String[] compileAndRunCode(String path) {
    try {
    k =runProcess("javac "+path+"/*.java");
    GetOutput.errorCount=k;
    GetCodeOutput.errorCount=k;
    if (k==0){
 
    	k =runProcess("java -cp "+ path+" Main");
    }
    
    return s.split("\n");
    } catch (Exception e) {

      e.printStackTrace();
      return null;
    }
  }
}