package com.skc.lnd.jdbc.model;

public class QuestionAnswer {
	private String question;
	private String clue;
	private String studentId;
	private int questionId;
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public QuestionAnswer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public QuestionAnswer(String question, String clue) {
		super();
		this.question = question;
		this.clue = clue;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getClue() {
		return clue;
	}
	public void setClue(String clue) {
		this.clue = clue;
	}
	
	
}
