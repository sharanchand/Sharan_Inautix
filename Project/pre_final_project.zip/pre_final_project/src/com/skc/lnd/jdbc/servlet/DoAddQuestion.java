package com.skc.lnd.jdbc.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.skc.lnd.jdbc.dao.impl.UserDaoImpl;
import com.skc.lnd.jdbc.model.QuestionAnswer;
import com.skc.lnd.jdbc.util.ConnectionFactory;
/**
 * Servlet implementation class DoAddQuestion
 */
@WebServlet("/DoAddQuestion")
public class DoAddQuestion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoAddQuestion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = ConnectionFactory.getConnection();
		HttpSession session=request.getSession(false);
		
		String studentId=(String) session.getAttribute("studentId");
		String question=(String)request.getParameter("question");
		String clue=(String)request.getParameter("clue");
		//String correctAnswer=(String)request.getAttribute((String)request.getAttribute("correctAnswer"));
		System.out.println(studentId+"\n"+question+"\n"+clue);
		if((question.length()!=0)){
			
			QuestionAnswer questionAnswer=new QuestionAnswer(question,clue);
			boolean ch;
			try {
				ch = UserDaoImpl.addQuestion(conn,questionAnswer,studentId);
			
			if(ch)
			{
				request.setAttribute("sucessful", "Question Added Sucessfully");
			}
			else
			{
				request.setAttribute("unsucessful", "Unsucessful in adding question");
			}
			} catch (SQLException e) {
				request.setAttribute("unsucessful", "Unsucessful in adding question");
			}
		}
		else{
			request.setAttribute("unsucessful", "Enter Question first");
		}
		
		RequestDispatcher dispacher= this.getServletContext().getRequestDispatcher("/WEB-INF/views/admin/AddQuestion.jsp");
		dispacher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
