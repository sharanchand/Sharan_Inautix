package com.skc.lnd.jdbc.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.skc.lnd.jdbc.model.*;

@WebServlet("/GetOutput")
public class GetOutput extends HttpServlet {

	private static final long serialVersionUID = 3884172034085800540L;
	public static int errorCount = 0;

	public GetOutput() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		UploadServlet.counter = 0;
		errorCount = 0;
		HttpSession session = request.getSession(false);
		String path = (String) session.getAttribute("filePath");
		System.out.println("Path : " + path);
		String message[] = JavaCompiler.compileAndRunCode(path);
		for(String mess:message)
			System.out.println("3 : "+mess);
		if (errorCount != 0) {
			request.setAttribute("errorMessage", message);
			System.out.println("Error in Compilation");
			for(String mess:message)
				System.out.println("1 : "+mess);
		} else {

			request.setAttribute("message", message);
			System.out.println("no Error");
			for(String mess:message)
				System.out.println("2 : "+mess);
		}
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/compileAndRun.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
