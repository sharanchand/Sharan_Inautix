package com.skc.lnd.jdbc.servlet;

import java.io.IOException;

import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.skc.lnd.jdbc.model.CreateAccount;

import com.skc.lnd.jdbc.dao.impl.*;
import com.skc.lnd.jdbc.util.*;
//import com.bnymellon.lnd.util.MyUtils;
public class Register extends HttpServlet {

	private static final long serialVersionUID = 365147486102526712L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();*/
		//Connection conn = MyUtils.getStoredConnection(request);
		Connection conn = ConnectionFactory.getConnection();
		boolean check=false;
		try{
			String sex=request.getParameter("sex").toUpperCase();
			String name=request.getParameter("sname").toUpperCase();
			String email=request.getParameter("email").toUpperCase();
			String password=request.getParameter("password");
			String repassword=request.getParameter("repassword");
			String contactNumber=(String)request.getParameter("contact");
			String question=request.getParameter("question").toUpperCase();
			String answer=request.getParameter("answer").toUpperCase();
			String coderName=request.getParameter("coderName");
			String userType=request.getParameter("user").toUpperCase();
			CreateAccount account= new CreateAccount(name, email, password, contactNumber, question,answer,coderName,sex,userType);
			if(!password.equals(repassword))
			{
				request.setAttribute("error", "Password mis-match, please try again.");
				request.getRequestDispatcher("signup.jsp").forward(request, response);
			}
			else
			{
				check=UserDaoImpl.findError(conn,account);
				if(check)
				{
					request.setAttribute("error1", "Email id or Contact Number in use");
					request.getRequestDispatcher("signup.jsp").forward(request, response);
				}
				else
				{
					boolean checking=UserDaoImpl.addUser(conn, account);
					if(checking){
					request.getRequestDispatcher("index.jsp").forward(request, response);
					}
					else
					{
						request.setAttribute("error1", "Something Went Wrong");
						request.getRequestDispatcher("signup.jsp").forward(request, response);
					}
				}
			}
			
		}
		catch(Exception e){}
		/*finally{
			out.close();
		}*/
	}

}
