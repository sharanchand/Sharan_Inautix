package com.skc.lnd.jdbc.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.skc.lnd.jdbc.dao.impl.UserDaoImpl;
import com.skc.lnd.jdbc.model.QuestionAnswer;
import com.skc.lnd.jdbc.util.ConnectionFactory;

/**
 * Servlet implementation class UploadAnswer
 */
@WebServlet("/UploadAnswer")
public class UploadAnswer extends HttpServlet {
	
  
	private static final long serialVersionUID = 8603131008218549303L;

	
    public UploadAnswer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);

		if (session.isNew()) {
			// System.out.println("New Session");
			RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
		} else {
			Connection conn = ConnectionFactory.getConnection();
			int questionId=Integer.parseInt(request.getParameter("questionId"));
			session.setAttribute("qID", questionId);
			try {
				QuestionAnswer questionAnswer=UserDaoImpl.getQuestionById(conn,questionId);
				if(questionAnswer!=null){
				session.setAttribute("question",questionAnswer);
				RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/user/questionSolution.jsp");
				dispatcher.forward(request, response);
				}
				else
				{
					session.invalidate();
					request.setAttribute("log","Something Went Wrong");
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
