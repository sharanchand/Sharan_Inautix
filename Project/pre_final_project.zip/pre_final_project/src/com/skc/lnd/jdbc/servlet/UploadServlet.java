package com.skc.lnd.jdbc.servlet;

//import org.apache.tomcat.util.http.fileupload.FileItem;
//check
//import org.apache.tomcat.util.http.fileupload.RequestContext;
//import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
//import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import java.io.File;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.skc.lnd.jdbc.model.CreateDirectory;

/**
 * Servlet implementation class UploadServlet
 */
@WebServlet("/UploadServlet")
public class UploadServlet extends HttpServlet {

	private static final long serialVersionUID = 5940696944902915224L;

	private boolean isMultipart = false;
	private String filePath;
	private String javaPath;
	private int maxFileSize = 50 * 1024;
	private int maxMemSize = 4 * 1024;
	private File file;
	private String fileName;
	public static int counter = 0;
	static String fPath;

	public UploadServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init() {
		// Get the file location where it would be stored.
		filePath = getServletContext().getInitParameter("file-upload");
		javaPath = getServletContext().getInitParameter("java-upload");
		fPath = filePath;
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, java.io.IOException {

		throw new ServletException("GET method used with " + getClass().getName() + ": POST method required.");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, java.io.IOException {
		// java.io.PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
		filePath = fPath;
		String javaPath1 = "";
		boolean folderCreated = false;
		String str=request.getParameter("questionIdChecks");

		String cName = (String) session.getAttribute("coder");
		filePath = filePath + cName + "\\";
		System.out.println("File Path : " + filePath);
		if (counter == 0) {
			javaPath1 = javaPath + cName;
			System.out.println("Java Path : " + javaPath1);
			session.setAttribute("filePath", javaPath1);
			folderCreated = CreateDirectory.createDir(filePath);
			System.out.println("folderCreated : " + folderCreated);
			counter++;
			System.out.println(counter);
		}

		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if (!isMultipart) {
			RequestDispatcher dispatcher = this.getServletContext()
					.getRequestDispatcher("/WEB-INF/views/user/codeTest.jsp");
			dispatcher.forward(request, response);
			return;
		}
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(maxMemSize);
		factory.setRepository(new File("c:\\temp"));
		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setSizeMax(maxFileSize);
		System.out.println("Outside try");
		try {

			System.out.println("inside try");
			System.out.println("filePath: " + filePath);
			// important
			List<FileItem> items = upload.parseRequest(request);
			Iterator<FileItem> i = items.iterator();
			while (i.hasNext()) {
				FileItem fi = (FileItem) i.next();
				if (!fi.isFormField()) {
					// Get the uploaded file parameters
					String fieldName = fi.getFieldName();
					fileName = fi.getName();
					String contentType = fi.getContentType();
					boolean isInMemory = fi.isInMemory();
					long sizeInBytes = fi.getSize();
					// Write the file
					if (fileName.lastIndexOf("\\") >= 0) {
						file = new File(filePath + fileName.substring(fileName.lastIndexOf("\\")));
					} else {
						file = new File(filePath + fileName.substring(fileName.lastIndexOf("\\") + 1));
					}
					fi.write(file);
					System.out.println("Uploaded Filename: " + fileName);
				}
			}
			request.setAttribute("message", fileName + "Upload Sucessful");
			
			System.out.println(str);
			System.out.println("Q ID: "+request.getParameter("questionIdCheck"));
			if(request.getParameter("questionIdCheck") != null)
			{
				RequestDispatcher dispatcher = this.getServletContext()
						.getRequestDispatcher("/WEB-INF/views/user/questionSolution.jsp");
				dispatcher.forward(request, response);
			}
			else{
			RequestDispatcher dispatcher = this.getServletContext()
					.getRequestDispatcher("/WEB-INF/views/user/codeTest.jsp");
			dispatcher.forward(request, response);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			request.setAttribute("error", "Upload Unsucessful");
			System.out.println("Caught Exception");
			RequestDispatcher dispatcher = this.getServletContext()
					.getRequestDispatcher("/WEB-INF/views/user/codeTest.jsp");
			dispatcher.forward(request, response);
		}
	}

}
