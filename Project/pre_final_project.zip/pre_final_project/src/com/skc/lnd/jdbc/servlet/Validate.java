package com.skc.lnd.jdbc.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.skc.lnd.jdbc.util.*;
import com.skc.lnd.jdbc.model.CreateAccount;
import com.skc.lnd.jdbc.dao.impl.*;

public class Validate extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3293209641050267665L;

	public Validate() {
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		try {
			CreateAccount user = null;
			//boolean hasError = false;
			String errorString = null;
			String email = request.getParameter("username").toUpperCase();
			String password = request.getParameter("password");
			//System.out.println(email+" "+password);
			Connection conn = ConnectionFactory.getConnection();

			try {

				user = UserDaoImpl.findUser(conn, email, password);

				if (user == null) {
					//hasError = true;
					errorString = "Invalid User";
					request.setAttribute("error", errorString);
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
				else {
					HttpSession session = request.getSession(true);
					session.setAttribute("name", user.getName());
					session.setAttribute("password", password);
					session.setAttribute("coder", user.getCoderName());
					session.setAttribute("studentId", user.studentId);
					session.setAttribute("type", user.getUserType());
					if (user.getUserType().equalsIgnoreCase("admin")) {
						request.getRequestDispatcher("/WEB-INF/views/admin/adminLoginView.jsp").forward(request, response);
					}
					else{
						request.getRequestDispatcher("/WEB-INF/views/user/home.jsp").forward(request, response);
						//System.out.println("Hello");
					}
				} 
			} 
			catch (SQLException e) {
				e.printStackTrace();
				errorString = e.getMessage();
			}

		}
		finally {
			out.close();
		}

	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("index.jsp").forward(req, resp);
	}
}
