package com.skc.lnd.jdbc.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.skc.lnd.jdbc.dao.impl.UserDaoImpl;
import com.skc.lnd.jdbc.model.QuestionAnswer;
import com.skc.lnd.jdbc.util.ConnectionFactory;

/**
 * Servlet implementation class ViewAllQuestions
 */
@WebServlet("/ViewAllQuestions")
public class ViewAllQuestions extends HttpServlet {
	

	private static final long serialVersionUID = -4028901508267361390L;

	
	public ViewAllQuestions() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);

		if (session.isNew()) {
			// System.out.println("New Session");
			RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
		} else {
			ArrayList <QuestionAnswer> list= new ArrayList <QuestionAnswer>();
			Connection conn = ConnectionFactory.getConnection();
			try {
				list=UserDaoImpl.getAllQuestions(conn);
				request.setAttribute("list", list);
			String type=(String)session.getAttribute("type");
			if(type.equalsIgnoreCase("admin")){
			RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/admin/listOfQuestions.jsp");
			dispatcher.forward(request, response);
			}
			else
			{
				RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/user/practiceQuestionList.jsp");
				dispatcher.forward(request, response);
			}
			} catch (SQLException e) {
				
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
