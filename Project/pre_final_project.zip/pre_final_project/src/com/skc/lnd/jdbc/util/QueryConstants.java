package com.skc.lnd.jdbc.util;

public class QueryConstants {
	public static final String INSERT_USER = "Insert into STUDENT_DETAILS_XBBNHBK(STUDENT_ID,STUDENT_NAME,STUDENT_EMAIL,CONTACT_NUMBER,PASSCODE,CODER_NAME,GENDER,QUESTION,ANSWER,USER_TYPE)"
			+ "values (?,?,?,?,?,?,?,?,?,?)";
	public static final String FIND_USER = "Select a.Student_EMail, a.Passcode, a.Student_Name, a.Coder_NAME, a.USER_TYPE, a.STUDENT_ID FROM STUDENT_DETAILS_XBBNHBK a where a.Student_EMail = ? and a.Passcode= ?";
	//public static final String UPDATE_USER = "UPDATE GD_LOGIN SET LOGIN_ID=?,PASSWORD=?,ROLE=? WHERE  LOGIN_ID=?";
	//public static final String DELETE_USER= "DELETE FROM GD_LOGIN WHERE LOGIN_ID=?";
	//public static final String SELECT_USER = "SELECT * FROM GD_LOGIN WHERE LOGIN_ID=? AND PASSWORD=?";
	//public static final String SELECT_USER_BY_ID = "SELECT * FROM GD_LOGIN WHERE LOGIN_ID=?";
	//public static final String SELECT_ALL_USER = "SELECT * FROM GD_LOGIN ORDER BY ROLE";
	public static final String FIND_ERROR ="Select a.Student_EMail from STUDENT_DETAILS_XBBNHBK a where a.Student_EMail = ? or a.Contact_Number = ?";
	public static final String SEARCH_ID="select STUDENT_ID from STUDENT_DETAILS_XBBNHBK where rownum=1 order by STUDENT_ID desc";
	public static final String ADD_QUESTION="INSERT INTO QUESTION_ANSWER_XBBNHBK VALUES(?,?,?,?)";
	public static final String SEARCH_QUESTION_ID="SELECT QUESTION_ID FROM QUESTION_ANSWER_XBBNHBK WHERE ROWNUM=1 ORDER BY QUESTION_ID DESC";
	public static final String ALL_QUESTIONS="SELECT * FROM QUESTION_ANSWER_XBBNHBK";
	public static final String GET_QUESTION_BY_ID="SELECT QUESTION, CLUE FROM QUESTION_ANSWER_XBBNHBK WHERE QUESTION_ID= ?";
}
