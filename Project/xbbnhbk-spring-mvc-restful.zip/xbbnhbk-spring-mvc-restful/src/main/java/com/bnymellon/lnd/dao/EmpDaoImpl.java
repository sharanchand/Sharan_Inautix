package com.bnymellon.lnd.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.bnymellon.lnd.models.Emp;
import com.bnymellon.lnd.util.EmpRowMapper;

public class EmpDaoImpl {
	private JdbcTemplate template;

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public int save(Emp e)
	{
		String querry="INSERT INTO EMP99 VALUES ("+e.getId()+",'"+e.getName()+"',"+e.getSalary()+",'"+e.getDesignation()+"')";
		System.out.println(querry);
		return template.update(querry);
	}
	
	public int update(int searchById, Emp newEmp)
	{
		String querry="UPDATE EMP99 SET NAME = '"+newEmp.getName()+"', SALARY= "+newEmp.getSalary()+", DESIGNATION= '"+newEmp.getDesignation()+"' WHERE ID ="+newEmp.getId();
		System.out.println(querry);
		return template.update(querry);
	}
	
	public int delete(int searchById)
	{
		String querry="DELETE FROM EMP99 WHERE ID="+searchById;
		return template.update(querry);
	}
	
	public Emp getEmployeeById(int searchById)
	{
		Emp foundEmployee =null;
		String querry="SELECT * FROM EMP99 WHERE ID="+searchById;
		foundEmployee=template.queryForObject(querry,new EmpRowMapper());
		return foundEmployee;
	}
	
	public List<Emp> getAllEmployee()
	{
		List<Emp> allEmployee=null;
		String querry="SELECT * FROM EMP99";
		allEmployee= template.query(querry, new EmpRowMapper());
		return allEmployee;
	}
}
