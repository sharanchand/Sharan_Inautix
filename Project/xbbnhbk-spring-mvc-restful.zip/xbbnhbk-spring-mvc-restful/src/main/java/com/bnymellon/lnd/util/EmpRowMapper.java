package com.bnymellon.lnd.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bnymellon.lnd.models.Emp;


public class EmpRowMapper implements RowMapper<Emp> {

	@Override
	public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Emp tempEmp=new Emp();
		tempEmp.setId(rs.getInt(1));
		tempEmp.setName(rs.getString(2));
		tempEmp.setSalary(rs.getFloat(3));
		tempEmp.setDesignation(rs.getString(4));
		return tempEmp;
	}

}
